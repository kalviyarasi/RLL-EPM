package com.example;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class PayrollTest {
  @Test
  public void payroll() throws InterruptedException {
	  System.setProperty("webdriver.chrome.driver","C:\\95\\chromedriver.exe");
	  WebDriver wd=new ChromeDriver();
	  wd.manage().window().maximize();
	  
	  //EPM
	  wd.get("http://localhost:4200/dashboard");
	  //Admin Login
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-dashboard/div/nav/div/div/a[1]/button")).click();
	  //Admin Register
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-login/div/div[2]/a/button")).click();
	  //Admin Register -Email, Username, Password, Confirm Password
	  wd.findElement(By.name("email")).sendKeys("bose47@gmail.com");
	  wd.findElement(By.name("username")).sendKeys("bose47");
	  wd.findElement(By.name("password")).sendKeys("bose123#");
	  wd.findElement(By.name("cpassword")).sendKeys("bose123#");
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[5]/button")).click();
	  
	  try {
		  WebDriverWait wait = new WebDriverWait(wd, 2);
		  wait.until(ExpectedConditions.alertIsPresent());
		  Alert alert = wd.switchTo().alert();
		  System.out.println(alert.getText());
    		alert.accept();
	  } catch (Exception e) {
		  //exception handling
	  }
	  
	  //Admin Login
	  wd.findElement(By.name("email")).sendKeys("bose47@gmail.com");
	  wd.findElement(By.name("password")).sendKeys("bose123#");
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-login/div/form/div[3]/button[1]")).click();
	  
	  //Add New Employee
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[2]/a")).click();
	  
	  wd.findElement(By.name("email")).sendKeys("ram@gmail.com");
	  wd.findElement(By.name("fName")).sendKeys("Ram");
	  wd.findElement(By.name("lName")).sendKeys("Raju");
	  wd.findElement(By.name("dob")).sendKeys("19-02-2000");
	  wd.findElement(By.xpath("/html/body/app-root/app-create-employee/div/div/form/div[5]/input[1]")).click();
	  wd.findElement(By.name("location")).sendKeys("Pune");
	  wd.findElement(By.name("street")).sendKeys("17, Indira nagar");
	  wd.findElement(By.name("city")).sendKeys("Chennai");
	  wd.findElement(By.name("pincode")).sendKeys("600074");
	  wd.findElement(By.name("state")).sendKeys("Tamilnadu");
	  wd.findElement(By.name("mobNo")).sendKeys("9000050000"); 
	  wd.findElement(By.name("pwd")).sendKeys("ramraju123#");
	  Select designation = new Select(wd.findElement(By.id("designation")));
	  designation.selectByIndex(1);
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-create-employee/div/div/form/div[14]/button[1]")).click();
	  
	  //Attendance List
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[3]/a")).click();
	  
	  wd.findElement(By.xpath("/html/body/app-root/app-attendance-list/div/nav/a[2]/button")).click();
	  wd.findElement(By.name("empId")).sendKeys("10001");
	  wd.findElement(By.name("date")).sendKeys("21-10-2022");
	  Select status = new Select(wd.findElement(By.id("status")));
	  status.selectByIndex(1);
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-createattendance/div/div/div/form/div[4]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-attendance-list/div/nav/a[3]/button")).click();
	  
	  //Timesheet List
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[4]/a")).click();
	  
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-timesheet-list/div/nav/a[2]/button")).click();
	  wd.findElement(By.name("empId")).sendKeys("10001");
	  wd.findElement(By.name("date")).sendKeys("212022");
	  wd.findElement(By.name("inTime")).sendKeys("0900a");
	  wd.findElement(By.name("outTime")).sendKeys("0500p");
	  Select regularTime = new Select(wd.findElement(By.name("regularTime")));
	  regularTime.selectByIndex(7);
	  Select breakTime = new Select(wd.findElement(By.name("breakTime")));
	  breakTime.selectByIndex(0);
	  Select overtimeHours = new Select(wd.findElement(By.name("overtimeHours")));
	  overtimeHours.selectByIndex(2);
	  Select totalHours = new Select(wd.findElement(By.name("totalHours")));
	  totalHours.selectByIndex(9);
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-createtimesheet/div/div/div/form/div[9]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-timesheet-list/div/nav/a[3]/button")).click();


	  //Schedule List
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[5]/a")).click();
	  
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-schedulelist/div/nav/a[2]/button")).click();
	  wd.findElement(By.name("empId")).sendKeys("10001");
	  wd.findElement(By.name("date")).sendKeys("21022022");
	  Select time1 = new Select(wd.findElement(By.name("time")));
	  time1.selectByIndex(0);
	  wd.findElement(By.name("stime")).sendKeys("0900a");
	  wd.findElement(By.name("etime")).sendKeys("0500p");
	  Select dtime = new Select(wd.findElement(By.name("dtime")));
	  dtime.selectByIndex(0);
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-createschedule/div/div/div/form/div[7]/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-schedulelist/div/nav/a[3]/button")).click();
	  
	  
	  //Leave List
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[6]/a")).click();
	  
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-leave-list/div/nav/a[2]/button")).click();
	  wd.findElement(By.name("empId")).sendKeys("10001");
	  Select leavetype = new Select(wd.findElement(By.name("leavetype")));
	  leavetype.selectByIndex(0);
	  wd.findElement(By.name("startdate")).sendKeys("09052022");
	  wd.findElement(By.name("enddate")).sendKeys("10072022");
	  Select duration = new Select(wd.findElement(By.name("duration")));
	  duration.selectByIndex(0);
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-create-leave/div/div/div/form/button")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-leave-list/div/nav/a[3]/button")).click();
	  
	  //Salary List
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[1]/li[7]/a")).click();
	  
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-salarylist/div/nav/a[2]/button")).click();
	  wd.findElement(By.name("employeeid")).sendKeys("10001");
	  wd.findElement(By.name("bp")).sendKeys("25000");
	  wd.findElement(By.name("da")).sendKeys(".00");
	  wd.findElement(By.name("hra")).sendKeys(".00");
	  wd.findElement(By.name("grosssalary")).sendKeys(".00");
	  wd.findElement(By.name("pfamount")).sendKeys(".00");
	  wd.findElement(By.name("tax")).sendKeys(".00");
	  wd.findElement(By.name("deduction")).sendKeys(".00");
	  wd.findElement(By.name("netPay")).sendKeys(".00");
	  wd.findElement(By.name("transdate")).sendKeys("24102022");
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-addsalary/div/div/div/form/button[1]")).click();
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-salarylist/div/nav/a[3]/button")).click();
	  
	  //Admin Logout
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employee-list/div[1]/nav/ul[2]/li/button")).click();
	  
	  //Admin to Home page
	  Thread.sleep(2000);
	  wd.navigate().back();
	  
	  //Employee Login
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-dashboard/div/nav/div/div/a[2]/button")).click();
	  wd.findElement(By.name("email")).sendKeys("ram@gmail.com");
	  wd.findElement(By.name("pwd")).sendKeys("ramraju123#");
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-emplogin/div/div/form/button[1]")).click();
	  
	  //Attendence
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[1]/button[2]")).click();
	  Thread.sleep(4000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeeattendance/div/div[2]/button")).click();
	  
	  //Timesheet
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[1]/button[3]")).click();
	  Thread.sleep(4000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeetimesheet/div/div[2]/button")).click();
	  
	  //Schedule
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[1]/button[4]")).click();
	  Thread.sleep(4000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeeschedule/div/div/div/button")).click();
	  
	  //Leave
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[1]/button[5]")).click();
	  Thread.sleep(4000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeeleave/div/div/div/button")).click();
	  
	  //PRINT
//	  Thread.sleep(1000);
//	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[2]/div[2]/table/tbody/tr/td[12]/button")).click();
	  
	  //LOGOUT
	  Thread.sleep(2000);
	  wd.findElement(By.xpath("/html/body/app-root/app-employeedashboard/div/div[1]/button[6]")).click();
	  
	  Thread.sleep(1000);
	  wd.findElement(By.xpath("/html/body/app-root/app-dashboard/div/div/div/button")).click();
	  Thread.sleep(3000);
	  JavascriptExecutor js = (JavascriptExecutor) wd;
      js.executeScript("window.scrollBy(0,document.body.scrollHeight)");

	  Thread.sleep(3000);
	  wd.close();
  }
}
