import { Schedule } from './schedule';

describe('Schedule', () => {
  it('should create an instance', () => {
    expect(new Schedule()).toBeTruthy();
  });
});
